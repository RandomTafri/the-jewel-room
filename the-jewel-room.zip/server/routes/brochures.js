const express = require('express');
const router = express.Router();
const db = require('../db');
const upload = require('../middleware/upload');
const { isAdmin } = require('../middleware/auth');

// Get all brochures
router.get('/', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM brochures ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// Admin: Upload Brochure
router.post('/', isAdmin, upload.single('file'), async (req, res) => {
    try {
        const { title } = req.body;
        const fileUrl = '/uploads/' + req.file.filename;

        const result = await db.query(
            'INSERT INTO brochures (title, file_url) VALUES ($1, $2) RETURNING *',
            [title, fileUrl]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error uploading brochure' });
    }
});

// Admin: Delete Brochure
router.delete('/:id', isAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        await db.query('DELETE FROM brochures WHERE id = $1', [id]);
        res.json({ message: 'Deleted' });
    } catch (err) {
        res.status(500).json({ error: 'Error deleting' });
    }
});

module.exports = router;
